
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="d-flex justify-content-center mt-4">
            <img src="<?php echo e(asset('papeid_logo.png')); ?>" height="60" alt="">
        </div>
        <form action="<?php echo e(url('list-wisata')); ?>">
            <div class="d-flex justify-content-between p-0">
                <div class="d-flex flex-row align-items-center mt-3 me-2 border rounded bg-white"
                    style="width: 80%; border-radius: 25px !important;">
                    <i class="bi bi-search me-1 ms-4" style="color: #c5c9d2;"></i>
                    <input type="text" name="cari" class="form-control search me-3" style="border: none; height: 46px;"
                        placeholder="Pilih Destinasi">
                </div>
                
                <button type="submit" class="btn btn-primary btn-sm mt-3" style="height: 46px; width: 20%; border-radius: 25px;">
                    <i class="bi bi-sliders2" style="font-size: 20px"></i>
                </button>
            </div>
        </form>
        <ul class="nav nav-lt-tab mt-4" style="border: 0;" role="tablist">
            <li class="nav-item" style="margin-right: 5px;">
                <a href="<?php echo e(url('list-wisata?cari=hot')); ?>" class="btn btn-primary mb-3"
                    style="border-radius: 20px; padding-left: 25px; padding-right: 25px;"><i class="bi bi-fire"></i> Hot</a>
            </li>
            <li class="nav-item" style="margin-right: 5px;">
                <a href="<?php echo e(url('list-wisata?cari=down')); ?>" class="btn btn-primary position-relative" onclick="getData(0)" id="0"
                    style="border-radius: 25px; padding-left: 25px; padding-right: 25px;"><i
                        class="bi bi-arrow-down-circle"></i> Koin Terendah</span>
                </a>
            </li>
            <li class="nav-item" style="margin-right: 5px;">
                <a href="<?php echo e(url('list-wisata?cari=up')); ?>" class="btn btn-primary" onclick="getData(1)" id="1"
                    style="border-radius: 25px; padding-left: 25px; padding-right: 25px;"><i
                        class="bi bi-arrow-up-circle"></i> Koin Tertinggi</a>
            </li>
        </ul>
        <div class="mb-3">
            <h3 style="margin-bottom: 0;">Trip Liburan</h3>
            <a href="<?php echo e(url('list-wisata?cari=all')); ?>">
                <span style="font-size: 12px;">Lihat Lainnya <i class="bi bi-arrow-right"></i></span>
            </a>
        </div>

        <?php
            $wisata = DB::table('wisatas')->inRandomOrder()->limit(6)->get();
            $produk = DB::table('produks')
                        ->select(
                            'produks.*', 
                            'users.name'
                        )
                        ->join('users', 'users.id', '=', 'produks.id_user')
                        ->inRandomOrder()->limit(6)->get();
        ?>


        <ul class="nav nav-lt-tab" style="border: 0;" role="tablist">
            <?php $__currentLoopData = $wisata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="nav-item" style="margin-right: 5px;">
                    <a href="<?php echo e(url('detail-wisata')); ?>/<?php echo e($item->id); ?>">
                        <div class="card" style="width: 200px; border-radius: 15px; border: none;">
                            <img style="border-radius: 15px; height: 150px; object-fit: cover; padding: 5px;"
                                src="<?php echo e(asset('gambar_wisata')); ?>/<?php echo e($item->gambar_1); ?>" class="card-img-top"
                                alt="...">
                            <div class="card-body" style="white-space: normal;">
                                <h5 class="card-title"><?php echo e(substr($item->judul_wisata, 0, 14)); ?> ...</h5>
                                <span style="font-size: 12px;"><i class="bi bi-calendar"></i> Berlaku hingga <?php echo e(date('d-m-Y', strtotime($item->kadaluarsa))); ?></span>
                                <span style="font-size: 12px;" class="text-warning"><i class="bi bi-coin"></i> <?php echo e(number_format($item->koin)); ?> Coin</span>
                            </div>
                        </div>
                    </a>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>

        <div class="mb-3 mt-4">
            <h3 style="margin-bottom: 0;">Produk UKM menarik <br>lainnya dari Pape.id</h3>
            <a href="<?php echo e(url('list-produk')); ?>">
                <span style="font-size: 12px;">Lihat Lainnya <i class="bi bi-arrow-right"></i></span>
            </a>
        </div>
        <ul class="nav nav-lt-tab" style="border: 0;" role="tablist">
            <?php $__currentLoopData = $produk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="nav-item" style="margin-right: 5px;">
                    <a href="<?php echo e(url('detail-produk')); ?>/<?php echo e($item->id); ?>">
                        <div class="card" style="width: 200px; border-radius: 15px; border: none;">
                            <img style="border-radius: 15px; height: 150px; object-fit: cover; padding: 5px;"
                                src="<?php echo e(asset('gambar_produk')); ?>/<?php echo e($item->gambar_1); ?>"
                                class="card-img-top">
                            <div class="card-body" style="white-space: normal;">
                                <h5 class="card-title"><?php echo e(substr($item->judul_produk, 0, 21)); ?> ...</h5>
                                <span style="font-size: 12px;" class="text-warning"><i class="bi bi-person"></i> <?php echo e($item->name); ?></span>
                            </div>
                        </div>
                    </a>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
    <br><br><br><br>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10.15.7/dist/sweetalert2.all.min.js"></script>
    <script>
        <?php if($message = Session::get('sukses')): ?>
            Swal.fire({
                icon: 'success',
                title: 'Sukses',
                text: 'Koin Berhasil Ditukarkan, untuk informasi lebih lanjut silahkan buka email anda',
                timer: 3000,
                showConfirmButton: false
            })
        <?php endif; ?>
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('frontend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\itpol\Documents\project\pape.id\resources\views/frontend/welcome.blade.php ENDPATH**/ ?>