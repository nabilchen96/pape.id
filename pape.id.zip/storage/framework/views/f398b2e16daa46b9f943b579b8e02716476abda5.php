
<?php $__env->startSection('content'); ?>
    <div class="d-flex justify-content-center mt-4">
        <img src="<?php echo e(asset('papeid_logo.png')); ?>" height="60" alt="">

    </div>
    <div class="container">
        <div class="card mt-4" style="border: none; border-radius: 15px;">
            <div class="card-body">
                <div class="text-center">
                    Total koin saya
                    <h1 class="text-warning"><i class="bi bi-coin"></i> <?php echo e(Auth::user()->koin); ?></h1>

                    <br>
                    Selesaikan task, dapatkan koinnya dan tukarkan dengan destinasi wisata yang diinginkan
                </div>
            </div>
        </div>
        <div class="mb-3 mt-5">
            <h3 style="margin-bottom: 0;">Daftar Tugas</h3>
            <span style="font-size: 12px;">Selesaikan Task dan Dapatkan Koin</span>
        </div>
        <?php
            $data = DB::table('tugas')
                ->where('kuota', '>', 0)
                ->paginate(3);
        ?>

        <div class="row">
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-6">
                    <div class="card mb-2" style="border-radius: 15px;">
                        <div class="card-body p-2">
                            <div class="d-flex justify-content-between">
                                <div class="card"
                                    style="
                                    background-size: cover;
                                    background-position: center;
                                    border: none;
                                    background-image: url('<?php echo e(asset('gambar_tugas')); ?>/<?php echo e($item->gambar); ?>'); 
                                    border-radius: 15px; 
                                    width: 35%">

                                </div>
                                <div style="margin-left: 10px; width: 65%;">
                                    <h6 class="mb-2 mt-1"><?php echo e(substr($item->judul_tugas, 0, 25)); ?></h6>
                                    <p>
                                        <?php echo e(substr($item->keterangan_tugas, 0, 45)); ?><a
                                            href="<?php echo e(url('detail-tugas')); ?>/<?php echo e($item->id); ?>">
                                            ...detail</a>
                                    </p>
                                    <span style="border-radius: 15px;" class="badge bg-primary"><?php echo e($item->kuota); ?>

                                        Orang</span>
                                    <span style="border-radius: 15px;" class="badge bg-warning"><?php echo e($item->koin); ?>

                                        koin</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="d-flex justify-content-center">
            <?php echo e($data->links()); ?>

        </div>
    </div>
    <br><br><br><br>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10.15.7/dist/sweetalert2.all.min.js"></script>
    <script>
        <?php if($message = Session::get('sukses')): ?>
            Swal.fire({
                icon: 'success',
                title: 'Sukses',
                text: 'Tugas Berhasil Diupload!',
                timer: 3000,
                showConfirmButton: false
            })
        <?php endif; ?>
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('frontend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\itpol\Documents\project\pape.id\resources\views/frontend/koin.blade.php ENDPATH**/ ?>