<div class="col-lg-12 px-4">
    <div class="row">
        <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="col-lg-3 p-lg-2 p-1 col-6 mt-3">
                <a href="<?php echo e(url('berita-detail')); ?>/<?php echo e($item->id); ?>" style="text-decoration: none;"
                    class="card shadow">
                    <img class="foto_berita" src="<?php echo e(asset('gambar_berita')); ?>/<?php echo e($item->gambar); ?>" />
                    <div class="card-body">
                        <div class="card-text" style="font-size: 14px">
                            <b class="judul_berita"><?php echo e($item->judul); ?></b>
                            <p class="mt-2 deskripsi_singkat"><?php echo e($item->deskripsi); ?></p>
                            <i class="bi bi-shop"></i>
                            <span style="margin-top: 10px"><?php echo e($item->name); ?></span>
                        </div>
                    </div>
                </a>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="col-lg-12 text-center mt-5">
                <img src="<?php echo e(asset('search.svg')); ?>" width="300px" height="300px" alt="">
                <h4 class="mt-2">Oop!, data yang anda cari tidak ditemukan</h4>
                <h6>Coba cari dengan kata kunci yang mendekati</h6>
            </div>
        <?php endif; ?>
    </div>
</div>
<?php /**PATH C:\Users\itpol\Documents\project\pape.id\resources\views/frontend/components/list-berita.blade.php ENDPATH**/ ?>