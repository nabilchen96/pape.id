<nav class="sidebar sidebar-offcanvas" id="sidebar">
    <ul class="nav">
        <li class="nav-item">
            <a class="nav-link" href="<?php echo e(url('dashboard')); ?>">
                <i class="icon-grid menu-icon"></i>
                <span class="menu-title">Dashboard</span>
            </a>
            
        </li>
        <li class="nav-item">
            <a class="nav-link" href="<?php echo e(url('back/user')); ?>">
                <i class="bi bi-person-fill menu-icon"></i>
                <span class="menu-title">User</span>
            </a>
        </li>
        <?php if(Auth::user()->role == 'Admin'): ?>
            
        <?php endif; ?>
        <li class="nav-item">
            <a class="nav-link" href="<?php echo e(url('back/wisata')); ?>">
                <i class="bi bi-image-alt menu-icon"></i>
                <span class="menu-title">Wisata</span>
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="<?php echo e(url('back/tugas')); ?>">
                <i class="bi bi-file-earmark-text menu-icon"></i>
                <span class="menu-title">Tugas</span>
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="<?php echo e(url('back/kumpul-task')); ?>">
                <i class="bi bi-file-earmark-text menu-icon"></i>
                <span class="menu-title">Kumpul Tugas</span>
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="<?php echo e(url('back/tukar-koin')); ?>">
                <i class="bi bi-arrow-repeat menu-icon"></i>
                <span class="menu-title">Tukar Koin</span>
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="<?php echo e(url('back/product')); ?>">
                <i class="bi bi-box-seam menu-icon"></i>
                <span class="menu-title">Produk</span>
            </a>
        </li>
        
        
        
        
        
    </ul>
</nav>
<?php /**PATH C:\Users\itpol\Documents\project\pape.id\resources\views/backend/components/navbar.blade.php ENDPATH**/ ?>