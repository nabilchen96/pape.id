
<?php $__env->startSection('content'); ?>
    <div
        style="
    height: 250px;
    margin: 0;
    background-position: center;
    background-repeat: no-repeat;
    background-size: cover;
    background-image: linear-gradient(black, transparent), url('<?php echo e(asset('gambar_wisata')); ?>/<?php echo e($detail->gambar_1); ?>')">

    </div>
    <div class="container">
        <div style="margin-top: -240px;">
            <div class="row">
                <div class="col-6">
                    <a href="<?php echo e(url('/home')); ?>">
                        <i class="bi bi-arrow-left-circle text-white" style="font-size: 30px;"></i>
                    </a>
                </div>
                <div class="col-6">

                </div>
            </div>
        </div>
        <div style="margin-top: 60px;">
            <h1 class="text-white">
                <?php echo e($detail->judul_wisata); ?>

            </h1>
            <h6 class="text-white">Berlaku hingga <?php echo e(date('d M Y', strtotime($detail->kadaluarsa))); ?></h6>
            <div class="card" style="border-radius: 15px;">
                <div class="card-body">
                    <h5>Tentang</h5>
                    <?php echo e($detail->keterangan); ?>

                    <br><br>
                    <h5>Foto</h5>
                    <ul class="nav nav-lt-tab" style="border: 0;" role="tablist">
                        <li class="nav-item" style="margin-right: 5px;">
                            <div class="card" style="width: 140px; border-radius: 15px; border: none;">
                                <img style="border-radius: 15px; height: 140px; object-fit: cover;"
                                    src="<?php echo e(asset('gambar_wisata')); ?>/<?php echo e($detail->gambar_1); ?>"
                                    class="card-img-top" alt="...">
                            </div>
                        </li>
                        <li class="nav-item" style="margin-right: 5px;">
                            <div class="card" style="width: 140px; border-radius: 15px; border: none;">
                                <img style="border-radius: 15px; height: 140px; object-fit: cover;"
                                    src="<?php echo e(asset('gambar_wisata')); ?>/<?php echo e($detail->gambar_2); ?>"
                                    class="card-img-top" alt="...">
                            </div>
                        </li>
                        <li class="nav-item" style="margin-right: 5px;">
                            <div class="card" style="width: 140px; border-radius: 15px; border: none;">
                                <img style="border-radius: 15px; height: 140px; object-fit: cover;"
                                    src="<?php echo e(asset('gambar_wisata')); ?>/<?php echo e($detail->gambar_3); ?>"
                                    class="card-img-top" alt="...">
                            </div>
                        </li>
                        <li class="nav-item" style="margin-right: 5px;">
                            <div class="card" style="width: 140px; border-radius: 15px; border: none;">
                                <img style="border-radius: 15px; height: 140px; object-fit: cover;"
                                    src="<?php echo e(asset('gambar_wisata')); ?>/<?php echo e($detail->gambar_4); ?>"
                                    class="card-img-top" alt="...">
                            </div>
                        </li>
                        <li class="nav-item" style="margin-right: 5px;">
                            <div class="card" style="width: 140px; border-radius: 15px; border: none;">
                                <img style="border-radius: 15px; height: 140px; object-fit: cover;"
                                    src="<?php echo e(asset('gambar_wisata')); ?>/<?php echo e($detail->gambar_5); ?>"
                                    class="card-img-top" alt="...">
                            </div>
                        </li>
                    </ul>
                    <br><br>
                </div>
            </div>
            <?php if($detail->koin > Auth::user()->koin): ?>
                <a style="border-radius: 25px; width: 100%;" class="btn btn-danger text-white shadow mt-4" type="button">
                    <h3><?php echo e(number_format($detail->koin)); ?> <i class="bi bi-coin"></i> Koin</h3>
                    Maaf, koin anda belum mencukupi

                    <?php echo e(\Auth::user()->koin); ?>

                </a>
            <?php else: ?>
                <a href="<?php echo e(url('tukar-koin')); ?>?id=<?php echo e($detail->id); ?>" style="border-radius: 25px; width: 100%;" class="btn btn-warning text-white shadow mt-4" type="button">
                    <h3>Tukar <?php echo e(number_format($detail->koin)); ?> <i class="bi bi-coin"></i> Koin</h3>
                </a>
            <?php endif; ?>
            <br><br>

            <div class="mb-3">
                <h3 style="margin-bottom: 0;">Trip Liburan</h3>
                <a href="<?php echo e(url('list-wisata?cari=all')); ?>">
                    <span style="font-size: 12px;">Lihat Lainnya <i class="bi bi-arrow-right"></i></span>
                </a>
            </div>
            <ul class="nav nav-lt-tab" style="border: 0;" role="tablist">
                <?php $__currentLoopData = $produk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="nav-item" style="margin-right: 5px;">
                        <a href="<?php echo e(url('detail-wisata')); ?>/<?php echo e($item->id); ?>">
                            <div class="card" style="width: 200px; border-radius: 15px; border: none;">
                                <img style="border-radius: 15px; height: 150px; object-fit: cover; padding: 5px;"
                                    src="<?php echo e(asset('gambar_wisata')); ?>/<?php echo e($item->gambar_1); ?>" class="card-img-top"
                                    alt="...">
                                <div class="card-body" style="white-space: normal;">
                                    <h5 class="card-title"><?php echo e(substr($item->judul_wisata, 0, 14)); ?> ...</h5>
                                    <span style="font-size: 12px;"><i class="bi bi-calendar"></i> Berlaku hingga <?php echo e(date('d-m-Y', strtotime($item->kadaluarsa))); ?></span>
                                    <span style="font-size: 12px;" class="text-warning"><i class="bi bi-coin"></i> <?php echo e(number_format($item->koin)); ?> Coin</span>
                                </div>
                            </div>
                        </a>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    </div>
    <br><br><br><br>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\itpol\Documents\project\pape.id\resources\views/frontend/detail-wisata.blade.php ENDPATH**/ ?>