
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="d-flex justify-content-center mt-4 mb-5">
            <img src="<?php echo e(asset('papeid_logo.png')); ?>" height="60" alt="">
        </div>
        
        <div class="mb-2">
            
        </div>

        <?php
            $wisata = DB::table('wisatas')->inRandomOrder()->limit(6)->get();
            $produk = DB::table('produks')
                        ->select(
                            'produks.*', 
                            'users.name'
                        )
                        ->join('users', 'users.id', '=', 'produks.id_user')
                        ->inRandomOrder()->paginate(6);
        ?>
        <div class="row">
            <?php $__currentLoopData = $produk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-6">
                    <a href="<?php echo e(url('detail-produk')); ?>/<?php echo e($item->id); ?>">
                        <div class="card mb-4" style="border-radius: 15px; border: none;">
                            <img style="border-radius: 15px; height: 150px; object-fit: cover; padding: 5px;"
                                src="<?php echo e(asset('gambar_produk')); ?>/<?php echo e($item->gambar_1); ?>" class="card-img-top"
                                alt="...">
                            <div class="card-body" style="white-space: normal;">
                                <h6 class="card-title"><?php echo e(substr($item->judul_produk, 0, 13)); ?> ...</h6>
                                <span style="font-size: 12px;" class="text-warning"><i class="bi bi-person"></i> <?php echo e($item->name); ?></span>
                            </div>
                        </div>
                    </a>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="d-flex justify-content-center">
            <?php echo e($produk->links()); ?>

        </div>
    </div>
    <br><br><br><br>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\itpol\Documents\project\pape.id\resources\views/frontend/list-produk.blade.php ENDPATH**/ ?>