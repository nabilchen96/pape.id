
<?php $__env->startSection('content'); ?>
    <style>
        html{
            height: 100%;
        }
        body{
            background-image: url('<?php echo e(asset('map.png')); ?>');
            background-size: cover;
            background-position: center;
        }
    </style>
    <div>
        <div class="d-flex justify-content-center mt-4">
            <img src="<?php echo e(asset('papeid_logo.png')); ?>" height="60" alt="">

        </div>

        <div class="container">
            <div class="card mt-4" style="border-radius: 15px;">
                <div class="card-body">
                    <div>
                        <h3>Syarat & Ketentuan</h3>
                        <br>
                        1. pada saat tukar koin akan ada email masuk dan semua
                        informasi ada di email tersebut contohnya tempat titik
                        kumpul dan tanggal berangkat. <br>
                        2. Setelah anda tekan tukar koin jumlah koin otomatis
                        berkurang sesuai dengan destinasi wisata. <br>
                        3. Biaya ke lokasi titik temu di tanggung sendiri sedangkan
                        ke lokasi wisata di tanggung penuh oleh pape.id <br>
                        4. Wisata hanya dilakukan selama 3 hari 2 malam dan tempat
                        wisata akan dipandu penuh oleh tim dari pape.id <br>
                        5. pape.id hanya akan menanggung biaya menginap dan
                        wisata. <br>

                        <?php
                            $koin = DB::table('wisatas')->where('id', request('id'))->value('koin');
                        ?>

                        <a href="<?php echo e(url('store-tukar-koin')); ?>?id=<?php echo e(request('id')); ?>" style="border-radius: 25px; width: 100%;" class="btn btn-warning text-white shadow mt-4" type="button">
                            <h3>Tukar <?php echo e($koin); ?> <i class="bi bi-coin"></i> Koin</h3>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\itpol\Documents\project\pape.id\resources\views/frontend/tukar-koin.blade.php ENDPATH**/ ?>