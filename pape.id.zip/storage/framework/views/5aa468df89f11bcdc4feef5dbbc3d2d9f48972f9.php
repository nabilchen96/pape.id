
<?php $__env->startSection('content'); ?>
    <div class="d-flex justify-content-center mt-4">
        <img src="<?php echo e(asset('papeid_logo.png')); ?>" height="60" alt="">

    </div>

    <div class="container">
        <div class="card mt-4" style="border: none; border-radius: 15px;">
            <div class="card-body">
                <div class="row">
                    <div class="col-6">
                        <img style="border-radius: 25px;" width="100%" height= "100%"; src="<?php echo e(asset('foto_profil')); ?>/<?php echo e($data->foto_profil ?? "office.jpg"); ?>"
                            alt="">
                    </div>
                    <div class="col-6">
                        <div class="text-start">
                            <h2><?php echo e($data->name); ?></h2>
                            <p><?php echo e($data->email); ?></p>
                            <h1 class="text-warning"><i class="bi bi-coin"></i> <?php echo e($data->koin ?? 0); ?></h1>
                            <button style="border-radius: 25px;" class="btn btn-primary">Edit</button>
                            <a style="border-radius: 25px;" class="btn btn-danger" href="<?php echo e(url('logout')); ?>">Logout</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <ul class="nav nav-lt-tab mt-4" style="border: 0;" role="tablist">
            <li class="nav-item" style="margin-right: 5px;">
                <a href="<?php echo e(url('user-profil')); ?>" class="btn btn-primary position-relative"
                    onclick="getData(0)" id="0"
                    style="border-radius: 25px; padding-left: 25px; padding-right: 25px;">Riwayat Tugas</span>
                </a>
            </li>
            <li class="nav-item" style="margin-right: 5px;">
                <a href="<?php echo e(url('user-profil?cari=riwayat-koin')); ?>" class="btn btn-primary mb-3"
                    style="border-radius: 20px; padding-left: 25px; padding-right: 25px;">Penukaran Koin</a>
            </li>
        </ul>
        <?php if(request('cari') == 'riwayat-koin'): ?>

        <div class="row">
            <?php $__currentLoopData = $tugas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-6">
                    <div class="card mb-2" style="border-radius: 15px;">
                        <div class="card-body p-2">
                            <div class="d-flex justify-content-between">
                                <div class="card"
                                    style="
                                background-size: cover;
                                background-position: center;
                                border: none;
                                background-image: url('<?php echo e(asset('gambar_wisata')); ?>/<?php echo e($item->gambar_1); ?>'); 
                                border-radius: 15px; 
                                width: 35%">

                                </div>
                                <div style="margin-left: 10px; width: 65%;">
                                    <h6 class="mb-2 mt-1"><?php echo e(substr($item->judul_wisata, 0, 25)); ?></h6>
                                    <p>
                                        <?php echo e(substr($item->keterangan, 0, 45)); ?><a
                                            href="<?php echo e(url('detail-tugas')); ?>/<?php echo e($item->id); ?>">
                                            ...detail</a>
                                    </p>
                                    Anda sudah menukar <br>
                                    <span style="border-radius: 15px;" class="badge bg-warning">
                                        <?php echo e($item->koin); ?> <i class="bi bi-coin"></i>
                                    </span>
                                    Koin
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <?php else: ?>

        <div class="row">
            <?php $__currentLoopData = $tugas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-6">
                    <div class="card mb-2" style="border-radius: 15px;">
                        <div class="card-body p-2">
                            <div class="d-flex justify-content-between">
                                <div class="card"
                                    style="
                                background-size: cover;
                                background-position: center;
                                border: none;
                                background-image: url('<?php echo e(asset('gambar_tugas')); ?>/<?php echo e($item->gambar); ?>'); 
                                border-radius: 15px; 
                                width: 35%">

                                </div>
                                <div style="margin-left: 10px; width: 65%;">
                                    <h6 class="mb-2 mt-1"><?php echo e(substr($item->judul_tugas, 0, 25)); ?></h6>
                                    <p>
                                        <?php echo e(substr($item->keterangan_tugas, 0, 45)); ?><a
                                            href="<?php echo e(url('detail-tugas')); ?>/<?php echo e($item->id); ?>">
                                            ...detail</a>
                                    </p>
                                    <?php if($item->status == 'Diterima'): ?>
                                        <span style="border-radius: 15px;" class="badge bg-success">Status: <?php echo e($item->status); ?></span>
                                    <?php elseif($item->status == 'Ditolak'): ?>
                                        <span style="border-radius: 15px;" class="badge bg-danger">Status:
                                            <?php echo e($item->status); ?></span>
                                    <?php else: ?>
                                        <span style="border-radius: 15px;" class="badge bg-warning">Status:
                                            <?php echo e($item->status); ?></span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
            
        <?php endif; ?>
        <div class="d-flex justify-content-center">
            <?php echo e($tugas->links()); ?>

        </div>
    </div>
    <br><br><br><br><br>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\itpol\Documents\project\pape.id\resources\views/frontend/user-profil.blade.php ENDPATH**/ ?>